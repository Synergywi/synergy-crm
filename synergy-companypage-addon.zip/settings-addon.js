// settings addon placeholder
