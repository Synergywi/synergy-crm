
/**
 * Tabs Add-on (Safe, One-shot per render)
 * - Disconnects observer while mutating to avoid loops
 * - Uses a render token on <main> so it runs once per render
 * - Never hides content unless tabs are successfully created
 */
(function(){
  const H  = (r,s)=> (r||document).querySelector(s);
  const HA = (r,s)=> Array.from((r||document).querySelectorAll(s));
  const TXT= n => (n && (n.textContent||'').trim()) || '';

  const MAP = {
    case:    ["Case Notes","Tasks","Case Documents"],
    company: ["Company Contacts","Related Cases","Company Documents"],
    contact: ["Portal Access"]
  };

  let observer = null;
  let lastToken = null;

  function whichPage(root){
    const h2 = H(root, "main .card h2, main h2");
    const header = TXT(h2);
    if (/^Case\b/i.test(header)) return "case";
    if (/^Company\b/i.test(header)) return "company";
    if (/^Contact\b/i.test(header)) return "contact";
    const active = H(root, "aside .nav li.active");
    const t = TXT(active);
    if (/^Cases/i.test(t)) return "case";
    if (/^Companies/i.test(t)) return "company";
    if (/^Contacts/i.test(t)) return "contact";
    return null;
  }

  function secRoot(h){
    let n=h;
    while(n && n!==document){
      if(n.classList && (n.classList.contains("section")||n.classList.contains("card"))) return n;
      n=n.parentNode;
    }
    return h;
  }

  function buildTabsOnce(root){
    const main = H(root,"main.main");
    if(!main) return false;

    // token for this render
    const token = main.getAttribute("data-render-token") || (Date.now()+"-"+Math.random().toString(36).slice(2));
    if(!main.hasAttribute("data-render-token")) main.setAttribute("data-render-token", token);
    if(lastToken === token) return false; // already processed
    lastToken = token;

    // skip if already tabified
    if(main.dataset.tabified==="1") return false;

    const page = whichPage(root);
    if(!page) return false;
    const wanted = MAP[page]||[];
    if(!wanted.length) return false;

    const found = HA(main, ".section header h3, h3.section-title, .section h3, .card h3, h3");
    const by = {};
    for(const h of found){
      const t=TXT(h);
      if(wanted.includes(t)) by[t]=h;
    }
    const present = wanted.filter(x=>by[x]);
    if(present.length===0) return false;

    const h2 = H(main, ".card h2, h2");
    const headerCard = h2 ? h2.closest(".card") : null;
    if(!headerCard) return false;

    // collect nodes after header
    const tail=[];
    let n=headerCard.nextElementSibling;
    while(n){ tail.push(n); n=n.nextElementSibling; }
    if(tail.length===0) return false;

    // Determine dedicated tab sections
    const labelToRoot={};
    for(const lbl of present){
      labelToRoot[lbl]=secRoot(by[lbl]);
    }
    const tabRoots=new Set(Object.values(labelToRoot));
    const defaults=[];
    for(const node of tail){
      if(!tabRoots.has(node)) defaults.push(node);
    }
    // fix append -> push
  }

    if(defaults.length===0 && present.length<2) return false;

    const defaultLabel = (page==="company")?"Summary":"Details";
    // UI
    const container=document.createElement("div");
    container.className="tabwrap card";
    const bar=document.createElement("div"); bar.className="tabsbar";
    const panes=document.createElement("div"); panes.className="tabscontent";
    container.append(bar, panes);

    function addTab(key,label,nodes){
      const b=document.createElement("button");
      b.className="tabbtn"; b.type="button"; b.dataset.tab=key; b.textContent=label;
      const p=document.createElement("div");
      p.className="tabpanel"; p.dataset.tab=key;
      nodes.forEach(nd=>p.appendChild(nd));
      bar.appendChild(b); panes.appendChild(p);
    }

    addTab("__default", defaultLabel, defaults);
    for(const lbl of present) addTab(lbl, lbl, [labelToRoot[lbl]]);

    // disconnect while mutating
    if(observer) observer.disconnect();
    headerCard.after(container);

    function activate(k){
      Array.from(container.querySelectorAll(".tabbtn")).forEach(b=>b.classList.toggle("active", b.dataset.tab===k));
      Array.from(container.querySelectorAll(".tabpanel")).forEach(p=>p.classList.toggle("active", p.dataset.tab===k));
    }
    activate("__default");
    bar.addEventListener("click", e=>{
      const b=e.target.closest(".tabbtn"); if(!b) return;
      activate(b.dataset.tab);
    });

    main.dataset.tabified="1";

    // reconnect observer
    if(observer){
      observer.observe(document.getElementById("app"), {childList:true, subtree:true});
    }
    return true;
  }

  function runSafe(){ try{ buildTabsOnce(document); }catch(e){ console.warn("tabs addon error:", e); } }

  document.addEventListener("DOMContentLoaded", runSafe);
  const app=document.getElementById("app");
  if(!app) return;
  let pending=false;
  observer=new MutationObserver(()=>{
    if(pending) return;
    pending=true;
    requestAnimationFrame(()=>{ pending=false; runSafe(); });
  });
  observer.observe(app,{childList:true,subtree:true});
})();
