/*! tabs-addon (disabled stub)
 * This stub intentionally does nothing. Replace your previous tabs-addon.js with this file
 * to immediately stop any render loops/freezes. Safe to leave deployed.
 */
(()=>{})();
