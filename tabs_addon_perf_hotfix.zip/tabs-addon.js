
/**
 * Tabs Add-on (Perf Hotfix)
 * - Throttled MutationObserver to prevent render loops/freezes.
 * - Only runs when <main> exists and is not already tabified.
 * - Never hides content unless a tab bar is successfully created.
 */
(function(){
  const H = (root, sel) => (root||document).querySelector(sel);
  const HA = (root, sel) => Array.from((root||document).querySelectorAll(sel));
  const TXT = n => (n && (n.textContent||'').trim()) || '';

  // Section map
  const MAP = {
    case:    ["Case Notes","Tasks","Case Documents"],
    company: ["Company Contacts","Related Cases","Company Documents"],
    contact: ["Portal Access"]
  };

  function whichPage(root){
    const h2 = H(root, "main .card h2, main h2");
    const header = TXT(h2);
    if (/^Case\b/i.test(header)) return "case";
    if (/^Company\b/i.test(header)) return "company";
    if (/^Contact\b/i.test(header)) return "contact";
    const active = H(root, "aside .nav li.active");
    const t = TXT(active);
    if (/^Cases/i.test(t)) return "case";
    if (/^Companies/i.test(t)) return "company";
    if (/^Contacts/i.test(t)) return "contact";
    return null;
  }

  function closestSectionFromHeading(h){
    let n = h;
    while(n && n !== document){
      if(n.classList && (n.classList.contains("section") || n.classList.contains("card"))) return n;
      n = n.parentNode;
    }
    return h;
  }

  function buildTabs(root){
    const main = H(root, "main.main");
    if(!main || main.dataset.tabified === "1") return false;

    const page = whichPage(root);
    if(!page) return false;

    const wanted = MAP[page] || [];
    if(!wanted.length) return false;

    const foundHeadings = HA(main, ".section header h3, h3.section-title, h3, .section h3, .card h3");
    const byLabel = {};
    for(const h of foundHeadings){
      const t = TXT(h);
      if (wanted.includes(t)) byLabel[t] = h;
    }
    const present = wanted.filter(lbl => byLabel[lbl]);
    if(present.length === 0) return false;

    const headerCard = (H(main, ".card h2") || {}).closest && H(main, ".card h2").closest(".card");
    if(!headerCard) return false;

    // Siblings after header card
    const after = [];
    let n = headerCard.nextElementSibling;
    while(n){
      after.push(n);
      n = n.nextElementSibling;
    }
    if(after.length === 0) return false;

    const container = document.createElement("div");
    container.className = "tabwrap card";
    const tabsbar = document.createElement("div");
    tabsbar.className = "tabsbar";
    const panels = document.createElement("div");
    panels.className = "tabscontent";
    container.appendChild(tabsbar);
    container.appendChild(panels);

    function addTab(key,label,nodes){
      const btn = document.createElement("button");
      btn.className = "tabbtn";
      btn.type = "button";
      btn.dataset.tab = key;
      btn.textContent = label;
      const panel = document.createElement("div");
      panel.className = "tabpanel";
      panel.dataset.tab = key;
      nodes.forEach(node => panel.appendChild(node));
      tabsbar.appendChild(btn);
      panels.appendChild(panel);
    }

    // Determine which nodes become dedicated tabs
    const labelToRoot = {};
    for(const lbl of present){
      const h = byLabel[lbl];
      labelToRoot[lbl] = closestSectionFromHeading(h);
    }
    const tabRoots = new Set(Object.values(labelToRoot));

    const defaultNodes = [];
    for(const node of after){
      if(!tabRoots.has(node)) defaultNodes.push(node);
    }

    // fix: Array.push not append
  }
})();

    if(defaultNodes.length === 0 && present.length < 2) return false;

    const defaultLabel = (page === "company") ? "Summary" : "Details";
    addTab("__default", defaultLabel, defaultNodes);
    for(const lbl of present){
      addTab(lbl, lbl, [labelToRoot[lbl]]);
    }

    headerCard.after(container);

    function activate(key){
      Array.from(container.querySelectorAll(".tabbtn")).forEach(b=>b.classList.toggle("active", b.dataset.tab===key));
      Array.from(container.querySelectorAll(".tabpanel")).forEach(p=>p.classList.toggle("active", p.dataset.tab===key));
    }
    activate("__default");

    tabsbar.addEventListener("click", e=>{
      const b = e.target.closest(".tabbtn");
      if(!b) return;
      activate(b.dataset.tab);
    });

    main.dataset.tabified = "1";
    return true;
  }

  function safeTabify(){
    try{ buildTabs(document); }catch(e){ console.warn("tabify error:", e); }
  }

  document.addEventListener("DOMContentLoaded", safeTabify);

  const app = document.getElementById("app");
  if(!app) return;
  let rafQueued = false;
  const mo = new MutationObserver(()=>{
    if(rafQueued) return;
    rafQueued = true;
    requestAnimationFrame(()=>{
      rafQueued = false;
      const main = document.querySelector("main.main");
      if(main && main.dataset.tabified !== "1") safeTabify();
    });
  });
  mo.observe(app, {childList:true, subtree:true});
})();
